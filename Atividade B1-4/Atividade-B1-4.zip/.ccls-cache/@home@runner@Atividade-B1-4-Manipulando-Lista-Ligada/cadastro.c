#include <stdio.h>
#include <stdlib.h>

void cadastro(No **lista) {
  No *Lista = (No *)malloc(sizeof(No)); // aloca memoria para o novo no
  int id;
  if (!Lista) {
    exit(1);
  }

  printf("\nDigite o id: ");  scanf("%d", &id);

  No *temp = *lista; // temp recebe o endereço do primeiro elemento da lista
  while (temp != NULL) {
    if (temp->id == id) { // verifica se o id já existe
      printf("ID já cadastrado!\n\n");
      return;
    }
    temp = temp->prox; // temp recebe o endereço do proximo elemento da lista
  }

  Lista->id = id;       // recebe o id digitado pelo usuario
  Lista->prox = *lista; // o proximo elemento da lista recebe o endereço do
                        // primeiro elemento da lista
  *lista = Lista;
  printf("ID Cadastrado\n\n");
}