#include <stdio.h>
/*----------------------------------------------------------------------------------*/
/*   FATEC-ZL                     Estrutura de Dados                                     */ 
/*                         Lab1 :  Listas - Estrutura de Arranjos                        */
/*                                  Prof. Carlos Henrique Ver�ssimo                        */
/*----------------------------------------------------------------------------------*/
/*   Programa :   pesquisa.exe                                                                      */
/*   Fun��o :     Pesquisa lista                                                                */
/*----------------------------------------------------------------------------------*/
struct lista {
   int info;
   struct lista* prox;
   };
typedef struct lista Lista;
   /* fun��o de cria��o : retorna uma lista vazia*/
Lista* lst_cria (void)
{
      printf("*----------------------------------------------------*\n");
printf("*            FATEC-ZL-    Estrutura de Dados         *\n");
printf("*LAB1 - 21/09/2005    ##Lista encadeada              *\n");
printf("*             Exemplo 4 : pesquisa Lista             *\n");
printf("*----------------------------------------------------*\n");   
   return NULL;
}
   /*inser��o no in�cio: retorna a lista atualizada*/
Lista* lst_insere (Lista* l, int i)
{
   Lista* novo = (Lista*) malloc(sizeof(Lista));
   novo->info = i;
  novo->prox = l;
  return novo;     
 /*  printf ("Valor recebido : %d\n", i);  */
}
/*----------------------------------------------------------------------*/
/*        fun��o imprime : Imprime valores dos elementos             */
/*----------------------------------------------------------------------*/
void lst_imprime (Lista* l)
{
   Lista* p;    /*Vari�vel auxiliar para percorrer a lista */
      for (p = l; p!= NULL; p = p->prox)
         printf("%d\n", p->info);
};
/*----------------------------------------------------------------------*/
/*Fun��o vazia : retorna 1 se vazia; 0 se n�o vazia                     */
/*----------------------------------------------------------------------*/
int lst_vazia (Lista* l)
{
  if (l == NULL)
       printf ("Lista V A Z I A\n");    
    else
      printf ("Lista Nao Vazia\n") ;  
     /* return 0;*/
};
/*----------------------------------------------------------------------*/
/*Fun��o busca : Busca um elemento na lista                              */
/*----------------------------------------------------------------------*/
int lst_busca (Lista* l, int v)
{
   Lista* p;
   for (p=l; p!=NULL; p=p->prox) {
      if (p->info == v) {
      printf ("Encontrou  : %d\n", v);    
      return 0;
      /*return p;   */
   }   
   else {
    printf ("Nao encontrou  : %d\n", v);  
    return 0;
   /*return NULL; /*n�o encontrou o elemento  */
   }
   }
}/*----------------------------------------------------------------------*/
/*                                  M A I N                                          */
/*----------------------------------------------------------------------*/
int main (void)
{
   Lista* l;                     /* Declara uma lista n�o inicializada*/
   l = lst_cria( );           /* Declara uma lista n�o inicializada*/
   l = lst_insere(l, 10);   /* Insere na lista o valor requeriedo*/
    l = lst_insere(l, 20);   /* Insere na lista o valor requeriedo*/
    l = lst_insere(l, 23);   /* Insere na lista o valor requeriedo*/
    l = lst_insere(l, 01);   /* Insere na lista o valor requeriedo*/
    l = lst_insere(l, 22);   /* Insere na lista o valor requeriedo*/
    l = lst_insere(l, 100);  /* Insere na lista o valor requeriedo */
    l = lst_insere(l, 45);   /* Insere na lista o valor requeriedo */
    l = lst_insere(l, 30);   /* Insere na lista o valor requeriedo */
    printf("*----------------------------------------------------*\n");
   printf("*                    Resultado na memoria            *\n");
   printf("*----------------------------------------------------*\n");
    lst_vazia(l);      /* Verifica Lista Vazia*/
   lst_imprime(l);           /* imprimir� os valores gravados na mem�ria*/
   lst_busca(l, 30);   /* Busca elemento*/
   lst_busca(l, 44);   /* Busca elemento*/
   return 0;
}