#include <stdio.h>
/*----------------------------------------------------------------------------------*/
/*   FATEC-ZL                     Estrutura de Dados                                     */ 
/*                         Lab1 :  Listas - Estrutura de Arranjos                        */
/*                                  Prof. Carlos Henrique Ver�ssimo                        */
/*----------------------------------------------------------------------------------*/
/*   Programa :   inserirl.exe                                                                      */
/*   Fun��o :     cria uma lista vazia,                                                       */
/*----------------------------------------------------------------------------------*/
struct lista {
   int info;
   struct lista* prox;
   };
typedef struct lista Lista;
   /* fun��o de cria��o : retorna uma lista vazia*/
Lista* lst_cria (void)
{
printf("*----------------------------------------------------*\n");
printf("*            FATEC-ZL-    Estrutura de Dados         *\n");
printf("*LAB1 - 21/09/2005    ##Lista encadeada              *\n");
printf("*             Exemplo 1 : Inser��o Novo elemento no inicio da lista*\n");
printf("*----------------------------------------------------*\n");   
 return NULL;
};
   /*inser��o no in�cio: retorna a lista atualizada*/
Lista* lst_insere (Lista* l, int i)
{
   Lista* novo = (Lista*) malloc(sizeof(Lista));
   novo->info = i;
  novo->prox = l;
  return novo;     
 /*  printf ("Valor recebido : %d\n", i);  */
}
   /*fun��o imprime : Imprime valores dos elementos */
void lst_imprime (Lista* l)
{
   Lista* p;    /*Vari�vel auxiliar para percorrer a lista */
   printf("*----------------------------------------------------*\n");
   printf("*                    Resultado na memoria            *\n");
   printf("*----------------------------------------------------*\n");
      for (p = l; p!= NULL; p = p->prox)
         printf("%d\n", p->info);
}
int main (void)
{
   Lista* l;                     /* Declara uma lista n�o inicializada*/
   l = lst_cria( );           /* Declara uma lista n�o inicializada*/
   l = lst_insere(l, 10);   /* Insere na lista o valor requeriedo*/
   l = lst_insere(l, 20);   /* Insere na lista o valor requeriedo*/
   l = lst_insere(l, 23);   /* Insere na lista o valor requeriedo*/
   l = lst_insere(l, 01);   /* Insere na lista o valor requeriedo*/
   l = lst_insere(l, 22);   /* Insere na lista o valor requeriedo*/
   l = lst_insere(l, 100);  /* Insere na lista o valor requeriedo*/
   l = lst_insere(l, 45);   /* Insere na lista o valor requeriedo*/
   l = lst_insere(l, 30);   /* Insere na lista o valor requeriedo*/
   lst_imprime(l);           /* imprimir� os valores gravados na me�ria*/
   return 0;
}