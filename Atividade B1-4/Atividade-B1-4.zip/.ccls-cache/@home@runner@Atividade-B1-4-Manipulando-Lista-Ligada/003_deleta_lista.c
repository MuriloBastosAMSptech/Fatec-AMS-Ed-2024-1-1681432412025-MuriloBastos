#include <stdio.h>
/*----------------------------------------------------------------------------------*/
/*   FATEC-ZL                     Estrutura de Dados                                     */ 
/*                         Lab1 :  Listas - Estrutura de Arranjos                        */
/*                                  Prof. Carlos Henrique Ver�ssimo                        */
/*----------------------------------------------------------------------------------*/
/*   Programa :   deleta.exe                                                                      */
/*   Fun��o :     retira uma lista vazia,                                                     */
/*----------------------------------------------------------------------------------*/
struct lista {
   int info;
   struct lista* prox;
   };
typedef struct lista Lista;
   /* fun��o de cria��o : retorna uma lista vazia*/
Lista* lst_cria (void)
{
   printf("*----------------------------------------------------*\n");
   printf("*            FATEC-ZL-    Estrutura de Dados         *\n");
   printf("*LAB1 - 21/09/2005    ##Lista encadeada              *\n");
   printf("*             Exemplo 6 : Deleta emento da lista        *\n");
   printf("*----------------------------------------------------*\n");   
 return NULL;
}
   /*inser��o no in�cio: retorna a lista atualizada*/
Lista* lst_insere (Lista* l, int i)
{
   Lista* novo = (Lista*) malloc(sizeof(Lista));
   novo->info = i;
  novo->prox = l;
  return novo;     
 /*  printf ("Valor recebido : %d\n", i);  */
}
/*----------------------------------------------------------------------*/
/*        fun��o imprime : Imprime valores dos elementos             */
/*----------------------------------------------------------------------*/
void lst_imprime (Lista* l)
{
   Lista* p;    /*Vari�vel auxiliar para percorrer a lista */
      for (p = l; p!= NULL; p = p->prox)
         printf("%d\n", p->info);
}
/*----------------------------------------------------------------------*/
/*Fun��o vazia : retorna 1 se vazia; 0 se n�o vazia                     */
/*----------------------------------------------------------------------*/
int lst_vazia (Lista* l)
{
  if (l == NULL)
       printf ("Lista V A Z I A\n");    
    else
      printf ("Lista Nao Vazia\n") ;  
      return 0;
}
/*----------------------------------------------------------------------*/
/*Fun��o busca : Busca um elemento na lista                              */
/*----------------------------------------------------------------------*/
int lst_busca (Lista* l, int v)
{
   Lista* p;
   for (p=l; p!=NULL; p=p->prox) {
      if (p->info == v) {
      printf ("Encontrou  : %d\n", v);    
      return 0;
      /*return p;   */
   }   
   else {
    printf ("Nao encontrou  : %d\n", v);  
    return 0;
   /*return NULL; /*n�o encontrou o elemento  */
   }
   }
}
/*----------------------------------------------------------------------*/
/*Fun��o deleta : deleta elemento da lista                              */
/*----------------------------------------------------------------------*/
int lst_deleta (Lista* l, int v)
{
 Lista* ant = NULL; /* ponteiro para elemento anterior*/  
 Lista* p = l;      /* ponteiro para percorrer a lista*/
 /*  procura elemento na lista, guardando anterior */
 while (p != NULL && p->info != v) {
    ant = p;
    p = p->prox;
   }
 /*  Verifica se achou elemento */
  if (p == NULL)
   printf ("Nao encontrou elemento para DELETAR :  %d\n", v );  
   return 1;       /*      n�o achou, retorna lista original*/ 
 /*  Retira  elemento */
  if (ant == NULL)  {
    /* retira elemento do in�cio*/
      l = p->prox;
     }
  else {
     /*  retira elemento do meio da lista*/
     ant->prox = p->prox;
     }
     
     free(p);
     return 0;
}
/*----------------------------------------------------------------------*/
/*                                  M A I N                                          */
/*----------------------------------------------------------------------*/
int main (void)
{
   Lista* l;                     /* Declara uma lista n�o inicializada*/
   l = lst_cria( );           /* Declara uma lista n�o inicializada*/
   printf("*----------------------------------------------------*\n");
   printf("*                    Resultado na memoria            *\n");
   printf("*----------------------------------------------------*\n");
   l = lst_insere(l, 10);   /* Insere na lista o valor requeriedo*/
    l = lst_insere(l, 20);   /* Insere na lista o valor requeriedo*/
    l = lst_insere(l, 23);   /* Insere na lista o valor requeriedo*/
    l = lst_insere(l, 01);   /* Insere na lista o valor requeriedo*/
    l = lst_insere(l, 22);   /* Insere na lista o valor requeriedo*/
    l = lst_insere(l, 100);  /* Insere na lista o valor requeriedo */
    l = lst_insere(l, 45);   /* Insere na lista o valor requeriedo */
    l = lst_insere(l, 30);   /* Insere na lista o valor requeriedo */
   lst_vazia(l);      /* Verifica Lista Vazia*/
   lst_imprime(l);           /* imprimir� os valores gravados na mem�ria*/
   lst_deleta(l, 90);   /* deleta  elemento*/
   lst_busca(l, 30);   /* Busca elemento*/
   printf("*----------------------------------------------------*\n");
   printf("*                    Deleta elemento 100            *\n");
   lst_deleta(l, 100);   /* deleta  elemento*/
   printf("*----------------------------------------------------*\n");
   printf("*                    Pesquisa elemento 100            *\n");
   lst_busca(l, 100);   /* Busca elemento*/
   return 0;
}