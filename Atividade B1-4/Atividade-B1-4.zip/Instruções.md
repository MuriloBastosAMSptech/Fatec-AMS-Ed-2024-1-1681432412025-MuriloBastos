Vimos que a lista ligada é uma estrutura de dados dinâmica que consiste em uma sequência de elementos chamados de NÓS, onde cada NÓ contém um valor e um ponteiro para o próximo NÓ na sequência.

# Você está a receber 5 códigos com as seguintes funcionalidades:
  1. Criar uma lista
  2. Inserir uma lista
  3. obter uma lista
  4. deletar um elemento da lista
  5. liberar lista

# Neste sentido pede-se:
  - Faça o "esquema"  de memória de cada programa. Deverá ser demonstrado o estado da memória para cada programa.(Representar dos fragmentos 1 a 4)

# Junte todos programas em um único programa, que recebe uma função da entrada e processa:
  0 - Sair
  1 - Incluir
  2 - Consultar
  3 - Deletar
  4 - Listar todos

  No final mostrar todas as variaveis do programa em formato tabela
  linhas diferentes, colunas iguais